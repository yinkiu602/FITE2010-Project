import logo from './logo.svg';
import './App.css';
import { useState } from 'react';
import web3 from "web3";
import React from 'react';

class TopNavigation extends React.Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (
            <div className="topNav">
                <span id="proj_Name">Project_Name</span>
                <button id="abc" onClick={this.props.connectWallet}>Connect to Wallet</button>
            </div>
        )
    }
}

class MainContent extends React.Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (
            <div className="mainContent"></div>
        )
    }
}


class App extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            account: ''
        }
        this.connectWallet = this.connectWallet.bind(this);
        this.checkConnection = this.checkConnection.bind(this);
        this.checkWalletIsConnected = this.checkWalletIsConnected.bind(this);
    }

    async checkConnection() {
        if (this.state.account.length !== 0) {
            return true;
        }
        if (window.ethereum) {
            console.log('MetaMask is installed!');
            let accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
            return accounts ? true : false;
        }
    }

    async connectWallet() {
        console.log('connectWallet');      
        if (!window.ethereum) {
            window.alert('Please install web3 wallet (Metamask).');
        }
        else {
            try {
                let accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
                if (accounts.length !== 0) {
                    const account = accounts[0];
                    this.setState({account});
                }
            }
            catch (err) {
                console.log(err);
            }
        }
    }

    async checkWalletIsConnected() {
        const {ethereum} = window;
        if (!ethereum) {
            console.log('Make sure you have metamask!');
            return;
        } 
        else {
            console.log('We have the ethereum object', ethereum);
            try {
                let accounts = await ethereum.request({ method: 'eth_requestAccounts' });
                console.log(accounts);
                if (accounts.length !== 0) {
                    const account = accounts[0];
                    this.setState({account});
                }
            }
            catch (err) {
                console.log(err);
            }
        }
    }

    render() {
        return (
            <div>
                <TopNavigation connectWallet={this.connectWallet}/>
                {this.state.account ? "" : <button onClick={this.connectWallet}>Connect Wallet</button>}
                <p>{this.state.account}</p>
            </div>
        )
    }
}


//function App() {
//  const [current, setCurrent] = useState();
//  const button = () => {
//    return (
//      <div>
//        <button onClick={connectWallet}>
//          Connect wallet
//        </button>
//      </div>
//    )
//  }
//  const checkConnection = async () => {
//    if (window.ethereum) {
//      console.log('MetaMask is installed!');
//      let accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
//      return accounts ? true : false;
//    }
//  }
//  const checkWalletIsConnected = async () => {
//    const {ethereum} = window;
//    if (!ethereum) {
//      console.log('Make sure you have metamask!');
//      return;
//    } 
//    else {
//      console.log('We have the ethereum object', ethereum);
//      try {
//        let accounts = await ethereum.request({ method: 'eth_requestAccounts' });
//        console.log(accounts);
//        if (accounts.length !== 0) {
//          const account = accounts[0];
//          setCurrent(account);
//        }
//      }
//      catch (err) {
//        console.log(err);
//      }
//    }
//  };
//  async function connectWallet() {
//    if (!window.ethereum) {
//      window.alert('Please install web3 wallet (Metamask).');
//    }
//    else {
//      try {
//        let accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
//        if (accounts.length !== 0) {
//          const account = accounts[0];
//          setCurrent(account);
//        }
//      }
//      catch (err) {
//        console.log(err);
//      }
//    }
//  }
//
//  return (
//    <div className="App">
//      <header className="App-header">
//        <img src={logo} className="App-logo" alt="logo" />
//        <p>
//          Edit <code>src/App.js</code> and save to reload.
//        </p>
//        {checkConnection() ? 'true' : button()}
//        <a
//          className="App-link"
//          href="https://reactjs.org"
//          target="_blank"
//          rel="noopener noreferrer"
//        >
//          Learn React
//        </a>
//      </header>
//    </div>
//  );
//}

export default App;
